package workernode;
/**
 *
 * @author karan
 */
public class HeartbeatTask implements Runnable {
    // Identifier for node sending the heartbeat
    private final String node;
    // Host address to which the heartbeat is sent
    private final String host;
    // Port number on the host for sending the heartbeat
    private final int port;
    
    // Constructor to initialise the HeartbeatTask (node, host, port)
    public HeartbeatTask(String node, String host, int port) {
        this.node = node;
        this.host = host;
        this.port = port;
    }
    
    // The run method for sending heartbeat messages
    public void run() {
        try {
            // Infinite loop for continous heartbeat
            while (true) {
                // heartbeat message
                String heartbeat = "HEARTBEAT," + node;
                // Send heartbeat message
                Message.sendMessage(heartbeat, host, port);
                // Pause sending heartbeat 30 seconds
                Thread.sleep(30000);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
