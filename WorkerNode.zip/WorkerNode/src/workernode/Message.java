package workernode;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

// Method sends a message to a specified (host and port)
public class Message {
    public static void sendMessage(String message, String host, int port) {
        try {
            // Convert the host name into a InetAddress
            InetAddress address = InetAddress.getByName(host);
            // Create a DatagramPacket to hold the messages (length, destination address, port)
            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), address, port);
            // Create a DatagramSocket to send packet
            DatagramSocket socket = new DatagramSocket();
            // Send packet through socket
            socket.send(packet);
            // Close socket
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
