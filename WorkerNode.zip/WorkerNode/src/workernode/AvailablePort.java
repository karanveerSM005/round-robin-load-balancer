package workernode;
/**
 *
 * @author karan
 */
import java.net.DatagramSocket;

public class AvailablePort {
    // Method find available port between the specified min and max range
    public static int getAvailablePort(int minPort, int maxPort) {
        // Loop through each port in the specified range
        for (int ports = minPort; ports < maxPort; ports++) {
            try {
                // Create a new DatagramSocket on current port
                DatagramSocket socket = new DatagramSocket(ports);
                // Close the socket
                socket.close();
                return ports;
            } catch (Exception ignored) {}
        }
        // If no available port are found put an error
        throw new RuntimeException("The port that was selected is not currently available");
    }
}

