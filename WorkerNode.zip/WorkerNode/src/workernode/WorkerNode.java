package workernode;
/**
 *
 * @author karan
 */
public class WorkerNode {
    public static void main(String[] args) {
        // Check if the correct number of arguments are provided
        if (args.length != 4) {
            return;
        }
        
        // Assign command line arguments to variables
        String loadbalancerHost = args[0];
        int loadbalancerPort;
        int minPort;
        int maxPort;

        try {
            // port numbers from the command line arguments
            loadbalancerPort = Integer.parseInt(args[1]);
            minPort = Integer.parseInt(args[2]);
            maxPort = Integer.parseInt(args[3]);
        } catch (NumberFormatException ex) {
            // Handles invalid port numbers are not valid integers
            System.out.println("Invalid port number.");
            return;
        }
        
        // Get an available port within range
        int myPort = AvailablePort.getAvailablePort(minPort, maxPort);
        String nodeName = "Node " + myPort;
        // Initialise the WorkerNodeService with nodes (name, port, LB details)
        WorkerNodeService node = new WorkerNodeService(nodeName, myPort, loadbalancerHost, loadbalancerPort);
        // Start the WorkerNodeService
        node.start();
    }
}