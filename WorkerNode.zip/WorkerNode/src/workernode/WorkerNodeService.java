package workernode;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class WorkerNodeService {
    // Name of worker node
    private final String nodeName;
    // Port on which the node listens for any incoming messages
    private final int nodePort;
    // Host address of load balancer
    private final String lbHost;
    // Port of load balancer
    private final int lbPort;
    
    // Initialise the worker node service with the necessary paramiters 
    public WorkerNodeService(String nodeName, int nodePort, String lbHost, int lbPort) {
        this.nodeName = nodeName;
        this.nodePort = nodePort;
        this.lbHost = lbHost;
        this.lbPort = lbPort;
    }
    
    // This method start the worker node service
    public void start() {
        try {
            // Create registration message for LB
            String regMessage = "REG," + lbHost + "," + nodePort + "," + nodeName;
            Message.sendMessage(regMessage, lbHost, lbPort);
            // Confirm registration
            System.out.println("Registered: " + nodeName);
            // Start new thread for sending heartbeat signals
            new Thread(new HeartbeatTask(nodeName, lbHost, lbPort)).start();
            // Listening for any incoming job
            listenForJobs();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Method to listen for incoming job request
    private void listenForJobs() {
        try (DatagramSocket socket = new DatagramSocket(nodePort)) {
            System.out.println(nodeName + " is listening on port " + nodePort);

            while (true) {
                byte[] buffer = new byte[1024]; // Prepare a buffer to receive incoming packet
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                // Receive a packet
                socket.receive(packet);
                // Convert the packet data to a string message
                String message = new String(packet.getData(), 0, packet.getLength()).trim();
                String[] parts = message.split(",");
                
                // Checks if messaage is a job request
                if (parts.length >= 3 && parts[0].equalsIgnoreCase("JOB")) {
                    int duration = Integer.parseInt(parts[1]);
                    String jobID = parts[2];
                    // Send back a confirmation message for the job received
                    String sent = "SENT," + nodeName + "," + jobID;
                    Message.sendMessage(sent, lbHost, lbPort);

                    System.out.println(nodeName + " has recieved the message and is currently working on Job " + jobID + " | for | " + duration + " seconds");
                    Thread.sleep(duration * 1000);

                    String finishedMessage = "FINISHED," + nodeName + "," + jobID;
                    Message.sendMessage(finishedMessage, lbHost, lbPort);
                    // Additional processing for job
                    System.out.println(nodeName + " has successfully executed Job " + jobID);
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
