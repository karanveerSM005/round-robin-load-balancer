package client;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        // Scanner to read inputs from the console
        Scanner scanner = new Scanner(System.in);
        // Checks if the correct number of arguments are provided
        if (args.length != 2) {
            System.out.println("java Client <LoadBalancerHost> <LoadBalancerPort>");
            return;
        }
        
        // LB host and port from the agument
        String loadbalancerHost = args[0];
        int loadbalancerPort;
        
        // parse the LB port number
        try {
            loadbalancerPort = Integer.parseInt(args[1]);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid port entered.");
            return;
        }

        try {
            // Displays menu options to the user
            System.out.println("|----------------|");
            System.out.println("| Client Program |");
            System.out.println("|----------------|");
            System.out.println();
            System.out.println("|--------------------------|");
            System.out.println("|     Select an option     |");
            System.out.println("|--------------------------|");
            System.out.println("| 1. Submit a Job          |");
            System.out.println("|--------------------------|");
            System.out.println("| 2. Request System STATUS |");
            System.out.println("|--------------------------|");
            System.out.println();
            // It reads all the user choice
            String choice = scanner.nextLine().trim();
            // Processes the users choices
            // if 1 it will ask for user to submit a job
            if (choice.equals("1")) {
                // Job ID variable
                System.out.println("Enter the Job ID (Integer):");
                String jobID = scanner.nextLine().trim();
                // Job Duration variable how long job runs for
                System.out.println("Enter the Job Duration in seconds:");
                String jobDuration = scanner.nextLine().trim();

                // Validation to ensure that inputs are in correct formats
                if (!(jobID.matches("\\d+") && jobDuration.matches("\\d+"))) {
                    System.out.println("Error: ID and Duration need to be valid integers");
                    return;
                }
                // if its successful it is sent to the LB
                String finalMessage = "JOB," + jobDuration + "," + jobID;
                sendMessage(finalMessage, loadbalancerHost, loadbalancerPort);
                System.out.println("Job request sent to Load Balancer: " + finalMessage);
            }
            
            // if option 2 is selected it sends the LB the message which makes the LB output the LB status
            else if (choice.equals("2")) {
                String statusMessage = "CURRENTSTATUS";
                sendMessage(statusMessage, loadbalancerHost, loadbalancerPort);
                System.out.println("CURRENTSTATUS request sent");
            }
            // Error message if its not successfully sent
            else {
                System.out.println("Invalid option");
            }
            // closes the input
            scanner.close();
        // Error handeling
        } catch (Exception ex) {
            System.out.println("Error not able to send job");
            ex.printStackTrace();
        }
    }
    // Sends a messaeg to specified hostr and port
    private static void sendMessage(String message, String host, int port) {
        try {
            InetAddress address = InetAddress.getByName(host);
            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), address, port);
            DatagramSocket socket = new DatagramSocket();
            socket.send(packet);
            socket.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

