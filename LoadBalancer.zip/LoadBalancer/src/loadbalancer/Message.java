package loadbalancer;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.util.LinkedList;

public class Message {
    // Queue to store incoming job messages
    private LinkedList<String> jobQueue = new LinkedList<>();
    // Instance of NodeManager to manage node operations
    private NodeManager manager;
    // Instance of Logger to log job completion
    private Logger logger;
    // Flags indicating if a job scheduling process is ongoing
    private boolean schedulJob = false;
    
    // Constructor to initialise Message with NodeManager + Logger
    public Message(NodeManager manager, Logger logger) {
        this.manager = manager;
        this.logger = logger;
    }
    
    // Method to handle incoming messages based on their type
    public void handleMessage(String message, DatagramPacket packet) {
        // Split the incoming message into parts based on commas
        String[] parts = message.trim().split(",");
        // Switch case to handle different types of messages
        switch (parts[0]) {
            // Registration message
            case "REG":
                // Extract port number
                int port = Integer.parseInt(parts[2]);
                // Get IP address from the packet
                String ip = packet.getAddress().getHostAddress();
                // Extract node name
                String name = parts[3];
                // Register the node with NodeManager
                manager.registerNode(ip, port, name, 2);
                System.out.println("Registered the Node: " + name);
                System.out.println();
                // Assign jobs from the queue
                assignQueueJob();
                break;
            
            // Job message
            case "JOB":
                // Add job message to the job queue
                jobQueue.add(message);
                 // Check if a job scheduling process is not already running
                if (!schedulJob) {
                     // Creates flag to indicate scheduling is in progress
                    schedulJob = true;
                    // New thread to handle job assignment
                    new Thread(() -> {
                        try {
                            // 1 second wait to collect jobs
                            Thread.sleep(1000); 
                            // Assign jobs from the queue
                            assignQueueJob();
                        } catch (InterruptedException ex) {
                            // Handles interruption
                            ex.printStackTrace();
                        } finally {
                            // Resets the flag to false
                            schedulJob = false;
                        }
                    }).start(); // Starts the thread
                }
                // Removes nodes as necessary
                manager.removeNodes();
                break;
            
            // Finished job messaeg
            case "FINISHED":
                // Extract who completed the job
                String finishedBy = parts[1];
                // Extracts job ID
                String jobId = parts[2];
                // Log the job completion
                System.out.println("| Completed Job | Job ID | " + jobId + " | completed by | " + finishedBy + " | at | " + new java.util.Date() + " |");
                logger.logJob(finishedBy, jobId);
                assignQueueJob();
                // Removes nodes as necessary
                manager.removeNodes();
                break;
            
            // Heartbeat message
            case "HEARTBEAT":
                // Update the heartbeat for node
                manager.updatedHeartbeat(parts[1]);
                // Log heartbeat
                System.out.println("Heartbeat from: " + parts[1]  + "\n");
                // Removes nodes as necessary
                manager.removeNodes();
                break;
            
            // Current status of system
            case "CURRENTSTATUS":
                // Removes nodes as necessary
                manager.removeNodes();
                System.out.println();
                // Status outputs
                System.out.println("Status:");
                // Number if nodes
                System.out.println("Number of Nodes: " + manager.getNodeCount());
                // Displays all nodes that are running
                manager.printNodes();
                // Total jobs in queue
                System.out.println("Total Jobs in the Queue waiting: " + jobQueue.size());
                // Number of completed job
                System.out.println("Total Completed Jobs: " + logger.getLogCount());
                break;
            
            // Message to say that the job has been assigned to a node
            case "SENT":
                System.out.println("SENT Job: " + parts[2] + " to " + parts[1] + " for execution");
                System.out.println();
                break;
            // Error message if message doesnt follow the above
            default:
                System.out.println("Error: Unknown Message");
        }
    }

    private void assignQueueJob() {
        // Loop as long as there are jobs in the queue
        while ((jobQueue.size() > 0) && (manager.getNodeCount() > 0)) {
            // Variable contains the shortest job identified
            String shortest = null;
             // Shortest time to maximum value
            int shortestTime = Integer.MAX_VALUE;
            // Iterates through each job in queue
            for (int i = 0; i < jobQueue.size(); i++) {
                // Get job from the queue
                String job = jobQueue.get(i);
                // Splits the job into parts
                String[] part = job.split(",");
                // Check if job is valid and has enough parts
                if ((part[0].toUpperCase().equals("JOB")) && (part.length >= 3)) {
                    try {
                        // The duration of the job
                        int duration = Integer.parseInt(part[1]);
                        // Checks if job has a shorter duration than the current shortest
                        if (duration < shortestTime) {
                            // Shortest time
                            shortestTime = duration;
                            // Shortest job
                            shortest = job;
                        }
                    } catch (NumberFormatException ignored) {
                        // Error message if everything fails
                        System.out.println("Error");
                    }
                }
            }
            // If no valid shortest job is found exit the loop
            if (shortest == null) {
                break;
                }
            boolean sent = manager.sendMessage(shortest);
            if (sent) {
                // Remove the job from the queue if sent 
                jobQueue.remove(shortest);
                System.out.println("Shortest Job: " + shortest);
            } else {
                // Print failure message
                System.out.println("Not able to assing Job: " + shortest);
                break;
            }
        }
    }
}

