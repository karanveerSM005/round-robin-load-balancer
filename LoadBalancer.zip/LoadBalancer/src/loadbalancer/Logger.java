package loadbalancer;
/**
 *
 * @author karan
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;

public class Logger {
    private LinkedList<String> jobLog = new LinkedList<>();
    // log jobs as they are completed
    public void logJob(String node, String jobId) {
        // Creates the formating of how the data is stored
        String log = "| Job ID | " + jobId + " | completed by | " + node + " | at | " + new Date() + " | ";
        // Add the log entry to the job Log list
        jobLog.add(log);
        
        // Writes the log entry to the file log.txt (it makes sure its able to write to it)
        try (FileWriter writer = new FileWriter("Log.txt", true)) {
            // Writes the log entry onto a new line
            writer.write(log + "\n");
        } catch (IOException ex) {
            // Prints error message if not successful
            System.out.println("Error: Unable to write to file (log.txt)");
            ex.printStackTrace();
        }
    }
    // Gets the count of log entries
    public int getLogCount() {
        return jobLog.size();
    }
}
