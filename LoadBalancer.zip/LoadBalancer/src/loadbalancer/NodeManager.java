package loadbalancer;
/**
 *
 * @author karan
 */
import java.util.LinkedList;

public class NodeManager {
    // Index for selection of nodes
    private int roundRobinIndex = 0;
    // List to contain registered nodes
    private LinkedList<RegisteredNode> availableNodes;
    
    // List of available nodes
    public NodeManager() {
        availableNodes = new LinkedList<>();
    }
    
    // Registers a new node and adds it to the available list
    public boolean registerNode(RegisteredNode newNode) {
        availableNodes.add(newNode);
        // Returns true upon successful registration
        return true;
    }
    
    // Overloaded method to register a node using its details
    public boolean registerNode(String ipAddress, int portNumber, String nodeName, int maxJobs) {
        return registerNode(new RegisteredNode(ipAddress, portNumber, nodeName, maxJobs));
    }
    
    // Sends a message to the next node
    public boolean sendMessage(String message) {
        // Check if there are available nodes
        // Return false if no nodes are available
        if (availableNodes.isEmpty()) return false;
        // Select the node based on the current index
        RegisteredNode node = availableNodes.get(roundRobinIndex);
        // Update the index for the next selection
        roundRobinIndex = (roundRobinIndex + 1) % availableNodes.size();
        // Attempt to send the message to the selected node
        boolean sent = node.sendMessage(message);
        
        // If the message is sent successfully and is a job message
        if (sent) {
            if (message.startsWith("JOB")) {
                // Split the message into parts
                String[] parts = message.split(",");
                // Check if the message has enough parts to assign a job
                if (parts.length >=3 ) {
                    // Assign the job to the node
                    node.setAssignedJob(parts[2]);
                }
            }
        }
        // Return the message was sent successfully
        return sent;
    }
    
    // Returns the count of registered nodes
    public int getNodeCount() {
        return availableNodes.size();
    }
    
    // Prints details of all registered nodes
    public void printNodes() {
        System.out.println("Registered Nodes:");
        for (int i = 0; i < availableNodes.size(); i++) {
            RegisteredNode node = availableNodes.get(i);
            // Print each node's details
            System.out.println(" > " + node.getNode());
        }
    }
    
    // Updates the heartbeat of a specific node based on its name
    public void updatedHeartbeat(String nodeName) {
        for (int i = 0; i < availableNodes.size(); i++) {
            RegisteredNode node = availableNodes.get(i);
            // Check if the current node matches the specified node name
            if (node.getNode().equals(nodeName)) {
                node.updateHeartbeat();
            }
        }
    }

    // Method removes nodes that have timed out
    public void removeNodes() {
        // Get the current time
        long current = System.currentTimeMillis();
        // Define timeout 30 seconds
        long timeout = 30000;

        for (int i = 0; i < availableNodes.size(); i++) {
            RegisteredNode node = availableNodes.get(i);
            // Logic to check and remove timed-out nodes
            if (current - node.getLastHeartbeat() > timeout) {
                System.out.println("Node: " + node.getNode() + " is none responsive this node will be removed from the system");        
        
                availableNodes.remove(i);
                // Adjust the round robin index
                if (roundRobinIndex >= i && roundRobinIndex > 0) roundRobinIndex--;
                // Decrement i for the removed node
                i--;
            }
        }
    }
}
