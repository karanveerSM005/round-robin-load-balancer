package loadbalancer;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class LoadBalancerServer {
    // Variable to store port number
    private final int port;
    // Message handle to process any incomming messages
    private Message handler;
    // Socket for receiving packets
    private DatagramSocket socket;
    
    // Sets up the socket
    public LoadBalancerServer(int port) {
        // Assign the provided port number
        this.port = port;
        // Create a new message handler
        this.handler = new Message(new NodeManager(), new Logger());
        try {
            // Create a cocket bound to the specified port
            this.socket = new DatagramSocket(port);
            // Shows that the system is running
            System.out.println("Load Balancer is running on port: " + port);
            System.out.println();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    // Starts tthe server and waits for incoming messages
    public void start() {
        try {
            // Infinite loop for continous listening
            while (true) {
                // holds incoming data
                byte[] data = new byte[1024];
                // Create to receive data
                DatagramPacket packet = new DatagramPacket(data, data.length);
                // Recive packet from socket
                socket.receive(packet);
                // Converts received data into string message
                String message = new String(packet.getData(), 0, packet.getLength()).trim();
                // Display received message
                System.out.println("Received: " + message);
                // passes message + packet to handler for processing
                handler.handleMessage(message, packet);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
