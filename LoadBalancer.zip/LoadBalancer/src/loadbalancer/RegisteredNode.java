package loadbalancer;
/**
 *
 * @author karan
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class RegisteredNode {
    // IP address of node
    private String nodeIP;
    // Port number of node
    private int nodePort;
    // Job assigned to the node
    private String assignedJob = "";
    // Current number of jobs processed by node
    private int currentJobs;
    // Last heartbeat received from the node
    private long lastHeartbeat;
    // Name of node
    private String nodeName;
    // Maximum number of jobs the node can complete
    private int maxJobs;

    // Constructor to initialise a RegisteredNode
    public RegisteredNode(String IP, int port, String name, int max) {
        // Set node IP
        this.nodeIP = IP;
        // Set node Port number
        this.nodePort = port;
        // initalise current job to 0
        this.currentJobs = 0;
        // Set last heartbeat to current time
        this.lastHeartbeat = System.currentTimeMillis();
        // Set node name
        this.nodeName = name;
        // Set maximum job 
        this.maxJobs = max;
    }
    
    // Method to send a message to the node
    public boolean sendMessage(String message) {
        try {
            // Get the InetAddress from the node IP
            InetAddress address = InetAddress.getByName(nodeIP);
            // Create DatagramSocket
            DatagramSocket socket = new DatagramSocket();
            // Create a packet with the message
            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), address, nodePort);
            // Send the packet
            socket.send(packet);
            // Close socket
            socket.close();
            return true;
            
        } catch (Exception ex) {
            return false;
        }
    }
    
    // Method to update last heartbeat
    public void updateHeartbeat() {
        lastHeartbeat = System.currentTimeMillis();
    }

    // Getter method for lastHeartbeat
    public long getLastHeartbeat() {
        // Return the last heartbeat 
        return lastHeartbeat;
    }
    
    // Getter method for assignedJob
    public String getAssignedJob() {
        // Return the job assigned to the node
        return assignedJob;
    }
    
    // Setter method for assignedJob
    public void setAssignedJob(String jobID) {
        // Set the assigned job to the job ID
        this.assignedJob = jobID;
    }
    
    public String getNode() {
        return nodeName;
    }
}

