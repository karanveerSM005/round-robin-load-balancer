package loadbalancer;
/**
 *
 * @author karan
 */
public class LoadBalancer {
    public static void main(String[] args) {
        // Variable which holds the port number
        int port;
        // Checks if one argument is provided
        if (args.length != 1) {
            // Displays if message that the load balancer is working
            System.out.println("LoadBalancer is running on Port: <Port>");
            System.out.println();
            return;
        }
        
        try {
            // Converts string to integer
            port = Integer.parseInt(args[0]);
        } catch (NumberFormatException ex) {
            // Error message if port is not working
            System.out.println("Load Balancer is running on an invalid port number");
            System.out.println();
            return;
        }
        // Creats instance of load balancer server with specified port
        LoadBalancerServer server = new LoadBalancerServer(port);
        server.start();
    }
}
